'use client';

import { CheckCircle2, Lock } from 'lucide-react';

interface ActiveVault {
  goal: string;
  beneficiary: string;
  publicKey: string;
  location: string;
}

interface DashboardProps {
  activeVault?: ActiveVault | null;
}

function shortenAddress(publicKey: string) {
  return `${publicKey.slice(0, 6)}...${publicKey.slice(-6)}`;
}

export default function Dashboard({ activeVault }: DashboardProps) {
  const isActive = activeVault !== null && activeVault !== undefined;
  const goal = activeVault?.goal ?? '₱ 100,000';
  const saved = isActive ? '₱ 0' : '₱ 45,000';
  const progress = isActive ? '0%' : '45%';

  return (
    <section className="relative overflow-hidden bg-[#84A98C]/10 px-6 py-24 md:px-12 lg:px-24">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-16 lg:flex-row">
        {/* Left: Description */}
        <div className="lg:w-1/2">
          <h2 className="mb-6 font-serif text-3xl leading-tight text-[#243B53] md:text-4xl">
            {isActive ? 'Your vault is active.' : 'Track your peace of mind.'}
          </h2>
          <p className="mb-8 text-lg text-[#2D3142]/70">
            {isActive
              ? 'Your goal is now connected to your Stellar wallet. From here, you can track progress, review the beneficiary, and keep the vault ready for future contributions.'
              : 'Your progress dashboard gives you a clear, calm overview of your vault. See your total saved, goal percentage, and remaining amount at a glance.'}
          </p>
          <ul className="mb-10 space-y-5">
            {[
              'Transparent progress tracking',
              'Immutable transaction history via Stellar',
              'Secure beneficiary management',
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-4 text-[#243B53]">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#84A98C]/20">
                  <CheckCircle2 className="h-4 w-4 text-[#84A98C]" />
                </div>
                <span className="font-medium">{item}</span>
              </li>
            ))}
          </ul>
          {isActive ? (
            <div className="rounded-xl border border-[#84A98C]/30 bg-white/70 p-4 font-mono text-sm text-[#243B53]">
              {activeVault ? shortenAddress(activeVault.publicKey) : null}
            </div>
          ) : (
            <button className="rounded-full bg-[#243B53] px-8 py-4 font-semibold text-white transition-colors hover:bg-[#243B53]/90">
              View Sample Dashboard
            </button>
          )}
        </div>

        {/* Right: Dashboard Preview */}
        <div className="w-full lg:w-1/2">
          <div className="relative rounded-2xl border border-[#243B53]/5 bg-white p-8 shadow-xl">
            <div className="absolute left-0 top-0 h-2 w-full rounded-t-2xl bg-[#84A98C]"></div>
            <div className="mb-8 flex items-center justify-between">
              <div>
                <p className="mb-1 text-sm uppercase tracking-wider text-[#2D3142]/70">Primary Vault</p>
                <h3 className="font-serif text-2xl text-[#243B53]">Final Expenses</h3>
              </div>
              <div className="rounded-full border border-[#E9C46A]/20 bg-[#FFFBF0] px-4 py-2">
                <span className="flex items-center gap-2 text-sm font-medium text-[#243B53]">
                  <Lock className="h-3 w-3 text-[#E9C46A]" /> Locked
                </span>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-8">
              <div className="mb-2 flex items-end justify-between">
                <span className="font-serif text-4xl text-[#243B53]">{saved}</span>
                <span className="mb-1 text-sm text-[#2D3142]/70">of {goal} goal</span>
              </div>
              <div className="h-3 w-full overflow-hidden rounded-full bg-[#FAF7F2]">
                <div
                  className="h-full rounded-full bg-[#84A98C]"
                  style={{ width: progress }}
                ></div>
              </div>
              <p className="mt-2 text-right text-xs text-[#2D3142]/70">{progress} Complete</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-xl border border-[#243B53]/5 bg-[#FAF7F2] p-4">
                <p className="mb-1 text-xs text-[#2D3142]/70">Next Contribution</p>
                <p className="font-medium text-[#243B53]">{isActive ? 'Ready to fund' : '₱ 1,500'}</p>
                <p className="mt-1 text-xs text-[#2D3142]/70">
                  {activeVault?.location ? activeVault.location : 'Due in 5 days'}
                </p>
              </div>
              <div className="rounded-xl border border-[#243B53]/5 bg-[#FAF7F2] p-4">
                <p className="mb-1 text-xs text-[#2D3142]/70">Beneficiary</p>
                <p className="font-medium text-[#243B53]">{activeVault?.beneficiary ?? 'Maria Santos'}</p>
                <p className="mt-1 flex items-center gap-1 text-xs text-[#84A98C]">
                  <CheckCircle2 className="h-3 w-3" /> {isActive ? 'Added' : 'Verified'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
