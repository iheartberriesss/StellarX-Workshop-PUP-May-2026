'use client';

import { motion } from 'framer-motion';
import {
  BadgeCheck,
  Fingerprint,
  KeyRound,
  Link2,
  Lock,
  Mail,
  Network,
  Phone,
  RotateCcw,
  Shield,
  User,
  Wallet,
} from 'lucide-react';
import { TierOption, PreferencesState } from '@/lib/types';

interface ReviewStepProps {
  finalGoal: string;
  location: string;
  selectedTier: TierOption | null;
  preferences: PreferencesState;
  publicKey: string | null;
  connecting: boolean;
  walletError: string | null;
  beneficiary: string;
  onBeneficiaryChange: (value: string) => void;
  onConfirm: () => void;
}

function shortenAddress(publicKey: string) {
  return `${publicKey.slice(0, 6)}...${publicKey.slice(-6)}`;
}

const securityItems = [
  {
    icon: Fingerprint,
    title: 'Biometric Verification',
    desc: 'Secure your access using on-device passkeys for instant, passwordless entry.',
    badge: 'Enabled',
    highlighted: true,
  },
  {
    icon: KeyRound,
    title: 'Hardware Wallet Integration',
    desc: 'Connect a Ledger or Trezor for added cold-storage protection.',
    badge: 'Optional',
    highlighted: false,
  },
  {
    icon: Network,
    title: 'Decentralized Storage',
    desc: 'Data persists on-chain with immutable audit logs and distributed recovery points.',
    badge: null,
    highlighted: true,
  },
  {
    icon: RotateCcw,
    title: 'Social Recovery',
    desc: 'Multi-sig protection ensures your assets move only when consensus is reached.',
    badge: null,
    highlighted: true,
  },
];

export default function ReviewStep({
  finalGoal,
  location,
  selectedTier,
  preferences,
  publicKey,
  connecting,
  walletError,
  beneficiary,
  onBeneficiaryChange,
  onConfirm,
}: ReviewStepProps) {
  const customization = [
    preferences.serviceType,
    preferences.wakeLength,
    preferences.wakeVenue,
    preferences.restingPlace,
  ]
    .filter(Boolean)
    .join(', ');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="mx-auto max-w-6xl"
    >
      <div className="mb-12 flex flex-wrap items-center justify-center gap-3 text-sm font-medium text-[#243B53]">
        {[
          ['1', 'Plan Selection', true],
          ['2', 'Digital Identity', true],
          ['3', 'Final Security', false],
        ].map(([number, label, muted], index) => (
          <div key={label} className="flex items-center gap-3">
            <div className={`flex items-center gap-2 ${muted ? 'opacity-60' : ''}`}>
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#243B53] text-sm font-bold text-white">
                {number}
              </span>
              <span className={muted ? 'hidden sm:inline' : 'font-bold'}>{label}</span>
            </div>
            {index < 2 ? <div className="h-px w-10 bg-[#243B53]/25" /> : null}
          </div>
        ))}
      </div>

      <div className="grid gap-10 lg:grid-cols-12 lg:items-start">
        <div className="space-y-6 lg:col-span-7">
          <div>
            <h2 className="mb-3 font-serif text-3xl text-[#243B53] md:text-4xl">
              Secure Your Legacy
            </h2>
            <p className="text-base leading-relaxed text-[#2D3142]/75">
              Verify your identity and link your permanent digital vault to the Stellar blockchain.
            </p>
          </div>

          <div className="rounded-2xl border border-[#243B53]/10 bg-white p-6 shadow-sm md:p-8">
            <div className="space-y-5">
              <label className="block text-sm font-medium text-[#2D3142]/80">
                Full Legal Name
                <div className="relative mt-2">
                  <input
                    type="text"
                    value={location}
                    readOnly
                    className="h-12 w-full rounded-lg border border-[#243B53]/20 bg-[#FAF7F2] px-4 pr-12 font-medium text-[#243B53] outline-none"
                  />
                  <User className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#243B53]/35" />
                </div>
              </label>

              <div className="grid gap-5 md:grid-cols-2">
                <label className="block text-sm font-medium text-[#2D3142]/80">
                  Email Address
                  <div className="relative mt-2">
                    <input
                      type="email"
                      placeholder="you@example.com"
                      className="h-12 w-full rounded-lg border border-[#243B53]/20 bg-white px-4 pr-12 text-[#243B53] outline-none transition focus:border-[#243B53] focus:ring-2 focus:ring-[#243B53]/10"
                    />
                    <Mail className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#243B53]/35" />
                  </div>
                </label>
                <label className="block text-sm font-medium text-[#2D3142]/80">
                  Contact Number
                  <div className="relative mt-2">
                    <input
                      type="tel"
                      placeholder="+63 900 000 0000"
                      className="h-12 w-full rounded-lg border border-[#243B53]/20 bg-white px-4 pr-12 text-[#243B53] outline-none transition focus:border-[#243B53] focus:ring-2 focus:ring-[#243B53]/10"
                    />
                    <Phone className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#243B53]/35" />
                  </div>
                </label>
              </div>

              <label className="block text-sm font-medium text-[#2D3142]/80">
                Release Beneficiary
                <input
                  type="text"
                  placeholder="Wallet Address or Full Name"
                  value={beneficiary}
                  onChange={(event) => onBeneficiaryChange(event.target.value)}
                  className="mt-2 h-12 w-full rounded-lg border border-[#243B53]/20 bg-white px-4 text-[#243B53] outline-none transition focus:border-[#243B53] focus:ring-2 focus:ring-[#243B53]/10"
                />
              </label>

              <div className="border-t border-[#243B53]/10 pt-5">
                <div className="flex gap-4 rounded-xl bg-[#84A98C]/10 p-5">
                  <Shield className="mt-0.5 h-5 w-5 shrink-0 text-[#2F6F45]" />
                  <div>
                    <p className="font-semibold text-[#2F6F45]">Privacy Encryption Enabled</p>
                    <p className="mt-1 text-sm leading-relaxed text-[#2D3142]/75">
                      Your data is hashed and stored using bank-grade encryption standards.
                      Only your designated beneficiaries can request access decryption.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-4 rounded-2xl border border-red-100 bg-red-50 p-6">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-red-100 bg-white shadow-sm">
              <Lock className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <h4 className="mb-2 font-semibold text-red-900">Stellar Security Notice</h4>
              <p className="text-sm leading-relaxed text-red-800/80">
                By clicking below, you deploy a Soroban smart contract. These funds are
                legally time-locked and cannot be withdrawn early for leisure. They will
                only unlock upon verified death certificate submission to protect your family.
              </p>
            </div>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            {securityItems.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className={`rounded-xl border p-5 shadow-sm ${
                    item.highlighted
                      ? 'border-[#84A98C]/25 bg-[#84A98C]/10'
                      : 'border-[#243B53]/20 bg-white'
                  }`}
                >
                  <div className="mb-4 flex items-start justify-between gap-3">
                    <Icon className="h-5 w-5 text-[#243B53]" />
                    {item.badge ? (
                      <span
                        className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase ${
                          item.badge === 'Enabled'
                            ? 'bg-[#2F6F45] text-white'
                            : 'bg-[#FAF7F2] text-[#243B53]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    ) : null}
                  </div>
                  <p className="font-semibold text-[#243B53]">{item.title}</p>
                  <p className="mt-2 text-sm leading-relaxed text-[#2D3142]/75">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        <aside className="space-y-6 lg:sticky lg:top-28 lg:col-span-5">
          <div className="relative overflow-hidden rounded-2xl bg-[#243B53] p-7 text-white shadow-xl">
            <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full border-[28px] border-white/5" />
            <div className="relative z-10">
              <h3 className="mb-7 flex items-center gap-2 font-serif text-2xl text-white">
                <Wallet className="h-5 w-5 text-[#E9C46A]" />
                Vault Summary
              </h3>

              <div className="mb-8">
                <p className="text-sm text-white/70">Target Protection Goal</p>
                <p className="mt-1 font-serif text-5xl font-semibold text-white">{finalGoal}</p>
                <div className="mt-5 h-2 overflow-hidden rounded-full bg-white/20">
                  <div className="h-full w-[2%] rounded-full bg-[#84A98C]" />
                </div>
              </div>

              <div className="rounded-xl border border-white/10 bg-white/10 p-5">
                <div className="mb-5 flex items-start justify-between gap-4">
                  <span className="text-sm text-white/85">Initial Activation Deposit</span>
                  <span className="font-semibold text-white">₱1,000.00</span>
                </div>
                <div className="space-y-3 border-l border-white/15 pl-4 text-sm">
                  <div className="flex justify-between gap-4">
                    <span className="text-white/70">Soroban Contract Gas</span>
                    <span className="font-medium text-[#84A98C]">₱0.05</span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-white/70">Stellar Network Reserve</span>
                    <span className="font-medium text-[#84A98C]">₱1.00</span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-white/70">Security Audit Fee</span>
                    <span className="font-medium text-[#E9C46A]">Covered</span>
                  </div>
                </div>

                <div className="mt-6 border-t border-white/15 pt-5">
                  <div className="flex justify-between gap-4">
                    <div>
                      <p className="font-semibold text-white">Total Deposit Due</p>
                      <p className="text-xs uppercase tracking-[0.18em] text-white/50">
                        Signed on Stellar
                      </p>
                    </div>
                    <p className="font-serif text-2xl font-semibold text-white">₱1,000.00</p>
                  </div>
                </div>
              </div>

              {customization ? (
                <div className="mt-6 rounded-xl border border-white/10 bg-white/5 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-white/50">
                    Funeral Customization
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-white/80">{customization}</p>
                </div>
              ) : null}

              {selectedTier ? (
                <div className="mt-4 rounded-xl border border-white/10 bg-white/5 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-white/50">
                    Selected Tier
                  </p>
                  <p className="mt-2 font-semibold text-white">{selectedTier.name}</p>
                  <p className="mt-1 text-sm text-white/70">{selectedTier.price}</p>
                </div>
              ) : null}

              {publicKey ? (
                <div className="mt-4 rounded-xl border border-[#84A98C]/30 bg-[#84A98C]/10 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-white/50">
                    Stellar Wallet
                  </p>
                  <p className="mt-2 font-mono text-sm text-white">{shortenAddress(publicKey)}</p>
                </div>
              ) : null}

              <button
                type="button"
                onClick={onConfirm}
                disabled={!beneficiary || connecting}
                className="mt-8 flex w-full items-center justify-center gap-3 rounded-xl bg-[#84A98C] px-6 py-4 font-semibold text-[#243B53] shadow-lg transition-colors hover:bg-[#E9C46A] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Link2 className="h-5 w-5" />
                {connecting ? 'Waiting for Freighter...' : 'Connect Freighter Wallet & Deposit'}
              </button>

              <p className="mt-5 text-center text-xs leading-relaxed text-white/65">
                Secured by Stellar Soroban. You will be redirected to Freighter to sign
                the initial liquidity transaction.
              </p>

              {walletError ? (
                <p className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
                  {walletError}
                </p>
              ) : null}
            </div>
          </div>

          <div className="flex items-center justify-between gap-4 rounded-2xl border border-[#243B53]/10 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#84A98C]/15">
                <Fingerprint className="h-5 w-5 text-[#243B53]" />
              </div>
              <div>
                <p className="font-semibold text-[#243B53]">Immutable Record</p>
                <p className="text-sm text-[#2D3142]/70">Verified by Soroban Smart Contracts</p>
              </div>
            </div>
            <BadgeCheck className="h-5 w-5 text-[#2F6F45]" />
          </div>
        </aside>
      </div>
    </motion.div>
  );
}
