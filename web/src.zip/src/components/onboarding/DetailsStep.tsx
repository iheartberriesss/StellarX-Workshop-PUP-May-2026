'use client';

import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { TierOption, PreferencesState } from '@/lib/types';
import { tierOptions } from '@/lib/constants';

interface DetailsStepProps {
  preferences: PreferencesState;
  selectedTier: TierOption | null;
  onPreferenceChange: (key: keyof PreferencesState, value: string) => void;
  onTierSelect: (tier: TierOption) => void;
  onContinue: () => void;
}

export default function DetailsStep({
  preferences,
  selectedTier,
  onPreferenceChange,
  onTierSelect,
  onContinue,
}: DetailsStepProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="mx-auto max-w-3xl"
    >
      <div className="mb-10 text-center">
        <p className="mb-3 text-xs font-medium uppercase tracking-[0.2em] text-[#84A98C]">
          Step 2 of 3
        </p>
        <h2 className="mb-4 font-serif text-3xl text-[#243B53] md:text-4xl">
          Detailed Funeral Customization
        </h2>
        <p className="text-lg text-[#2D3142]/80">
          Choose the service details that shape your target goal.
        </p>
      </div>

      <div className="space-y-8">
        {/* Religion/Service Style */}
        <div className="rounded-2xl border border-[#243B53]/5 bg-white p-6 shadow-sm md:p-8">
          <h3 className="mb-4 font-serif text-xl text-[#243B53]">
            1. Religion / Service Style
          </h3>
          <div className="flex flex-wrap gap-3">
            {[
              'Catholic',
              'Christian / Evangelical',
              'Iglesia ni Cristo',
              'Islam',
              'Non-Religious / Secular',
            ].map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => onPreferenceChange('religion', option)}
                className={`rounded-full border px-4 py-2 text-sm font-medium transition-all ${preferences.religion === option ? 'border-[#243B53] bg-[#243B53] text-white' : 'border-[#243B53]/10 bg-[#FAF7F2] text-[#243B53] hover:border-[#243B53]/30'}`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Service Type */}
        <div className="rounded-2xl border border-[#243B53]/5 bg-white p-6 shadow-sm md:p-8">
          <h3 className="mb-4 font-serif text-xl text-[#243B53]">2. Service Type</h3>
          <div className="flex flex-col gap-3">
            {[
              {
                label: 'Traditional Burial',
                desc: 'Casket, wake, and ground burial/mausoleum',
              },
              {
                label: 'Cremation + Memorial Wake',
                desc: 'Cremation followed by a traditional viewing/wake',
              },
              {
                label: 'Direct Cremation',
                desc: 'Immediate cremation with no public wake or viewing',
              },
            ].map((option) => (
              <button
                key={option.label}
                type="button"
                onClick={() => onPreferenceChange('serviceType', option.label)}
                className={`rounded-xl border p-4 text-left transition-all ${preferences.serviceType === option.label ? 'border-[#84A98C] bg-[#84A98C]/10 text-[#243B53]' : 'border-[#243B53]/10 bg-[#FAF7F2] hover:border-[#243B53]/30'}`}
              >
                <div className="mb-1 font-medium text-[#243B53]">{option.label}</div>
                <div className="text-sm text-[#2D3142]/70">{option.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Wake Length */}
        <div className="rounded-2xl border border-[#243B53]/5 bg-white p-6 shadow-sm md:p-8">
          <h3 className="mb-4 font-serif text-xl text-[#243B53]">3. Wake Length</h3>
          <div className="flex flex-wrap gap-3">
            {[
              { label: 'No Wake', desc: 'Direct cremation/burial' },
              { label: '1 to 2 Days', desc: '' },
              { label: '3 Days', desc: 'Standard Philippine average' },
              { label: '5 to 7 Days', desc: 'Premium / Waiting for relatives' },
            ].map((option) => (
              <button
                key={option.label}
                type="button"
                onClick={() => onPreferenceChange('wakeLength', option.label)}
                className={`flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-all ${preferences.wakeLength === option.label ? 'border-[#243B53] bg-[#243B53] text-white' : 'border-[#243B53]/10 bg-[#FAF7F2] text-[#243B53] hover:border-[#243B53]/30'}`}
              >
                {option.label}
                {option.desc ? (
                  <span className="hidden text-xs opacity-70 sm:inline">({option.desc})</span>
                ) : null}
              </button>
            ))}
          </div>
        </div>

        {/* Wake Venue and Resting Place */}
        <div className="grid gap-8 md:grid-cols-2">
          <div className="rounded-2xl border border-[#243B53]/5 bg-white p-6 shadow-sm">
            <h3 className="mb-4 font-serif text-lg text-[#243B53]">4. Wake Venue</h3>
            <div className="flex flex-col gap-2">
              {[
                'Home Wake',
                'Local Barangay / Community Hall',
                'Funeral Home Chapel (Standard)',
                'Funeral Home Chapel (Premium)',
                'Church Facility',
              ].map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => onPreferenceChange('wakeVenue', option)}
                  className={`rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all ${preferences.wakeVenue === option ? 'border-[#243B53] bg-[#243B53] text-white' : 'border-[#243B53]/10 bg-[#FAF7F2] text-[#243B53] hover:border-[#243B53]/30'}`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Tier Selection */}
        <div className="mt-12 rounded-2xl bg-[#243B53] p-6 text-white shadow-lg md:p-8">
          <h3 className="mb-2 font-serif text-2xl text-[#E9C46A]">What is your budget?</h3>
          <p className="mb-6 text-sm text-white/70">
            Based on your selections, choose a target goal tier for your smart contract.
          </p>

          <div className="space-y-4">
            {tierOptions.map((tier) => (
              <button
                key={tier.id}
                type="button"
                onClick={() => onTierSelect(tier)}
                className={`w-full rounded-xl border p-5 text-left transition-all ${selectedTier?.id === tier.id ? 'border-[#E9C46A] bg-white/10 shadow-[0_0_15px_rgba(233,196,106,0.2)]' : 'border-white/10 bg-white/5 hover:border-white/30 hover:bg-white/10'}`}
              >
                <div className="mb-2 flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
                  <div className="font-serif text-lg text-white">{tier.name}</div>
                  <div className="inline-block w-fit rounded-full bg-[#E9C46A]/10 px-3 py-1 text-sm font-medium text-[#E9C46A]">
                    {tier.price}
                  </div>
                </div>
                <div className="text-sm leading-relaxed text-white/60">{tier.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-end border-t border-[#243B53]/10 pt-6">
          <button
            type="button"
            onClick={onContinue}
            disabled={!selectedTier}
            className="flex items-center gap-2 rounded-xl bg-[#E9C46A] px-8 py-4 font-semibold text-[#243B53] shadow-sm transition-colors hover:bg-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            Continue to Final Security <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
