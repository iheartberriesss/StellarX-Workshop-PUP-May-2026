'use client';

import { motion } from 'framer-motion';
import { TrendingUp, Calculator, ArrowRight } from 'lucide-react';

interface MethodStepProps {
  customGoal: string;
  onCustomGoalChange: (value: string) => void;
  onSelectCustom: () => void;
  onSelectCalculator: () => void;
}

export default function MethodStep({
  customGoal,
  onCustomGoalChange,
  onSelectCustom,
  onSelectCalculator,
}: MethodStepProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="mx-auto max-w-4xl"
    >
      <div className="mb-12 text-center">
        <h2 className="mb-4 font-serif text-3xl text-[#243B53] md:text-4xl">
          Choose Your Setup Method
        </h2>
        <p className="text-lg text-[#2D3142]/80">
          Select how you would like to determine your vault&apos;s target goal.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2">
        {/* Option A: Custom Goal */}
        <div className="flex h-full flex-col rounded-2xl border border-[#243B53]/5 bg-white p-8 shadow-sm">
          <div className="mb-6">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#84A98C]/10">
              <TrendingUp className="h-6 w-6 text-[#84A98C]" />
            </div>
            <h3 className="mb-2 font-serif text-xl text-[#243B53]">
              Option A: Set My Own Savings Goal
            </h3>
            <p className="mb-6 text-sm text-[#2D3142]/70">
              I already know how much I want to save for my final expenses.
            </p>

            <div className="relative mb-6">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 font-medium text-[#243B53]">
                ₱
              </span>
              <input
                type="number"
                placeholder="100,000"
                value={customGoal}
                onChange={(event) => onCustomGoalChange(event.target.value)}
                className="w-full rounded-xl border border-[#243B53]/10 bg-[#FAF7F2] py-4 pl-10 pr-4 font-medium text-[#243B53] transition-all focus:border-[#84A98C] focus:outline-none focus:ring-1 focus:ring-[#84A98C]"
              />
            </div>
          </div>
          <div className="mt-auto">
            <button
              type="button"
              onClick={onSelectCustom}
              disabled={!customGoal}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#243B53] px-6 py-4 font-semibold text-white transition-colors hover:bg-[#243B53]/90 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Skip to Vault Creation <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Option B: Calculator */}
        <div className="flex h-full flex-col rounded-2xl border border-[#243B53]/5 bg-white p-8 shadow-sm">
          <div className="mb-6">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#E9C46A]/10">
              <Calculator className="h-6 w-6 text-[#E9C46A]" />
            </div>
            <h3 className="mb-2 font-serif text-xl text-[#243B53]">
              Option B: Use the Funeral Cost Calculator
            </h3>
            <p className="text-sm text-[#2D3142]/70">
              Don&apos;t know how much it costs? Estimate your final expenses based on real local provider data.
            </p>
          </div>
          <div className="mt-auto">
            <button
              type="button"
              onClick={onSelectCalculator}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#E9C46A] px-6 py-4 font-semibold text-[#243B53] shadow-sm transition-colors hover:bg-[#E9C46A]/90"
            >
              Start Calculator <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
