// ViewState controls whether the app displays the landing page or the full onboarding flow.
export type ViewState = 'landing' | 'onboarding' | 'dashboard';

// OnboardingStep defines the four sequential screens used in the vault setup journey.
export type OnboardingStep = 'method' | 'location' | 'details' | 'review';

// A tier option represents a preset goal range with a title, price label, description, and numeric value.
export type TierOption = {
  id: string;
  name: string;
  price: string;
  desc: string;
  value: number;
};

// Preferences collected during the calculator flow
export type PreferencesState = {
  religion: string;
  serviceType: string;
  wakeLength: string;
  wakeVenue: string;
  restingPlace: string;
};
