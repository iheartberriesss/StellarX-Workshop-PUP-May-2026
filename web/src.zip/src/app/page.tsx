'use client';

import React, { useState } from 'react';

// Types and constants
import { ViewState, OnboardingStep, PreferencesState, TierOption } from '@/lib/types';
import { useWallet } from '@/hooks/useWallet';

// Landing page components
import LandingNav from '@/components/landing/LandingNav';
import Hero from '@/components/landing/Hero';
import Trust from '@/components/landing/Trust';
import Features from '@/components/landing/Features';
import Dashboard from '@/components/landing/Dashboard';
import Footer from '@/components/landing/Footer';

// Onboarding components
import OnboardingNav from '@/components/onboarding/OnboardingNav';
import MethodStep from '@/components/onboarding/MethodStep';
import LocationStep from '@/components/onboarding/LocationStep';
import DetailsStep from '@/components/onboarding/DetailsStep';
import ReviewStep from '@/components/onboarding/ReviewStep';

export default function Home() {
  // State management
  const { publicKey, connecting, error: walletError, connect } = useWallet();
  const [view, setView] = useState<ViewState>('landing');
  const [step, setStep] = useState<OnboardingStep>('method');
  const [customGoal, setCustomGoal] = useState('');
  const [location, setLocation] = useState('');
  const [preferences, setPreferences] = useState<PreferencesState>({
    religion: '',
    serviceType: '',
    wakeLength: '',
    wakeVenue: '',
    restingPlace: '',
  });
  const [selectedTier, setSelectedTier] = useState<TierOption | null>(null);
  const [beneficiary, setBeneficiary] = useState('');

  // Navigation helpers
  const handleStartOnboarding = () => {
    setView('onboarding');
    setStep('method');
    window.scrollTo(0, 0);
  };

  const handleLockVault = async () => {
    const connectedAddress = publicKey ?? await connect();
    if (!connectedAddress) return;

    setView('dashboard');
    window.scrollTo(0, 0);
  };

  const handleBack = () => {
    if (step === 'method') {
      setView('landing');
    } else if (step === 'location') {
      setStep('method');
    } else if (step === 'details') {
      setStep('location');
    } else if (step === 'review') {
      if (customGoal && !selectedTier) {
        setStep('method');
      } else {
        setStep('details');
      }
    }
    window.scrollTo(0, 0);
  };

  const updatePreference = (key: keyof PreferencesState, value: string) => {
    setPreferences((prev) => ({ ...prev, [key]: value }));
  };

  const resetFlow = () => {
    setView('landing');
    setStep('method');
    setCustomGoal('');
    setLocation('');
    setPreferences({
      religion: '',
      serviceType: '',
      wakeLength: '',
      wakeVenue: '',
      restingPlace: '',
    });
    setSelectedTier(null);
    setBeneficiary('');
    window.scrollTo(0, 0);
  };

  // Compute final goal display
  const finalGoal = selectedTier
    ? `₱${selectedTier.value.toLocaleString()}`
    : customGoal
      ? `₱${Number(customGoal.replace(/,/g, '') || 0).toLocaleString()}`
      : '₱0';

  if (view === 'dashboard' && publicKey) {
    return (
      <div className="min-h-screen bg-[#FAF7F2] font-sans text-[#243B53] selection:bg-[#E9C46A]/30">
        <OnboardingNav
          step="method"
          onBack={resetFlow}
          publicKey={publicKey}
          backLabel="New Estimate"
        />
        <Dashboard
          activeVault={{
            goal: finalGoal,
            beneficiary,
            publicKey,
            location,
          }}
        />
        <Footer />
      </div>
    );
  }

  // Onboarding view
  if (view === 'onboarding') {
    return (
      <div className="flex min-h-screen flex-col bg-[#FAF7F2] font-sans text-[#243B53] selection:bg-[#E9C46A]/30">
        <OnboardingNav step={step} onBack={handleBack} publicKey={publicKey} />

        <main className="flex-grow px-6 py-12 md:px-12">
          {step === 'method' && (
            <MethodStep
              customGoal={customGoal}
              onCustomGoalChange={setCustomGoal}
              onSelectCustom={() => {
                setSelectedTier(null);
                setStep('review');
                window.scrollTo(0, 0);
              }}
              onSelectCalculator={() => {
                setCustomGoal('');
                setStep('location');
                window.scrollTo(0, 0);
              }}
            />
          )}
          {step === 'location' && (
            <LocationStep
              location={location}
              onLocationChange={setLocation}
              onContinue={() => {
                if (location) {
                  setStep('details');
                  window.scrollTo(0, 0);
                }
              }}
            />
          )}
          {step === 'details' && (
            <DetailsStep
              preferences={preferences}
              selectedTier={selectedTier}
              onPreferenceChange={updatePreference}
              onTierSelect={setSelectedTier}
              onContinue={() => {
                if (selectedTier) {
                  setStep('review');
                  window.scrollTo(0, 0);
                }
              }}
            />
          )}
          {step === 'review' && (
            <ReviewStep
              finalGoal={finalGoal}
              location={location}
              selectedTier={selectedTier}
              preferences={preferences}
              publicKey={publicKey}
              connecting={connecting}
              walletError={walletError}
              beneficiary={beneficiary}
              onBeneficiaryChange={setBeneficiary}
              onConfirm={handleLockVault}
            />
          )}
        </main>
      </div>
    );
  }

  // Landing view
  return (
    <div className="min-h-screen bg-[#FAF7F2] font-sans text-[#243B53] selection:bg-[#E9C46A]/30">
      <LandingNav />
      <Hero onOpenVault={handleStartOnboarding} />
      <Trust />
      <Features />
      <Dashboard />
      <Footer />
    </div>
  );
}
